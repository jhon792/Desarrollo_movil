package com.example.desarrollo_movil21_activity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.desarrollo_movil21_activity.bdLite.DatabaseOperations;

public class AsignarDiaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asignar_dia);

        Spinner spinnerDias = findViewById(R.id.spinnerDias);
        Button btnGuardar = findViewById(R.id.btnGuardarRutina);

        // Lista de días
        String[] dias = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dias);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDias.setAdapter(adapter);

        // Recibir el nombre de la rutina
        String nombre = getIntent().getStringExtra("nombre");

        // Validación básica
        if (nombre == null || nombre.trim().isEmpty()) {
            Toast.makeText(this, "Error: no se recibió el nombre de la rutina.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        btnGuardar.setOnClickListener(v -> {
            String diaSeleccionado = spinnerDias.getSelectedItem().toString();

            // Guardar en la base de datos
            DatabaseOperations db = new DatabaseOperations(this);
            db.open();
            db.guardarRutina(diaSeleccionado, nombre);
            db.close();

            Toast.makeText(this, "Rutina asignada a " + diaSeleccionado, Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}

