package com.example.desarrollo_movil21_activity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.desarrollo_movil21_activity.bdLite.DatabaseOperations;

public class DatosUsuarioActivity extends AppCompatActivity {

    private Button boton2;
    private EditText etIdUsuario, etNombre, etEdad, etObjetivo;
    private DatabaseOperations dbOperations;
    private String alias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla2);

        configurarInsets();
        inicializarBD();
        inicializarUI();
        configurarVisibilidadID();
        configurarBoton();
    }

    // ---------- CONFIGURACIONES Y SETUP ----------

    private void configurarInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.pantalla2),
                (v, insets) -> {
                    Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                    v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                    return insets;
                }
        );
    }

    private void inicializarBD() {
        dbOperations = new DatabaseOperations(this);
        dbOperations.open();
        alias = getIntent().getStringExtra("ALIAS");
    }

    private void inicializarUI() {
        boton2 = findViewById(R.id.btnSiguienteUsuario);
        etIdUsuario = findViewById(R.id.etIdUsuario);
        etNombre = findViewById(R.id.etNombre);
        etEdad = findViewById(R.id.etEdad);
        etObjetivo = findViewById(R.id.etObjetivo);
    }

    /** Oculta campos si proviene de registro nuevo */
    private void configurarVisibilidadID() {
        if (alias != null && !alias.isEmpty()) {
            etIdUsuario.setVisibility(View.GONE);

            View divider = findViewById(R.id.divider_id);
            if (divider != null) divider.setVisibility(View.GONE);
        }
    }

    private void configurarBoton() {
        boton2.setOnClickListener(v -> guardarUsuario());
    }

    // ---------- LÓGICA PRINCIPAL ----------

    private void guardarUsuario() {
        String nombre = etNombre.getText().toString().trim();
        String edadStr = etEdad.getText().toString().trim();
        String objetivo = etObjetivo.getText().toString().trim();

        if (!validarCampos(nombre, edadStr, objetivo)) return;

        try {
            int edad = Integer.parseInt(edadStr);

            if (alias != null && !alias.isEmpty()) {
                registrarNuevoUsuario(nombre, edad, objetivo);
            } else {
                actualizarUsuarioExistente(nombre, edad, objetivo);
            }

        } catch (NumberFormatException e) {
            mostrarMensaje("Por favor ingresa una edad válida");
        }
    }

    // ---------- VALIDACIONES ----------

    private boolean validarCampos(String nombre, String edad, String objetivo) {
        if (nombre.isEmpty() || edad.isEmpty() || objetivo.isEmpty()) {
            mostrarMensaje("Por favor completa todos los campos");
            return false;
        }
        return true;
    }

    // ---------- OPERACIONES BD ----------

    private void registrarNuevoUsuario(String nombre, int edad, String objetivo) {
        long userId = dbOperations.agregarUsuario(alias, nombre, edad, objetivo);

        if (userId != -1) {
            mostrarMensaje("Usuario registrado exitosamente");
            irAMenuPrincipal(userId);
        } else {
            mostrarMensaje("Error: el alias ya está en uso.");
        }
    }

    private void actualizarUsuarioExistente(String nombre, int edad, String objetivo) {
        String idStr = etIdUsuario.getText().toString().trim();

        if (idStr.isEmpty()) {
            mostrarMensaje("Por favor ingresa un ID de usuario");
            return;
        }

        long existingUserId = Long.parseLong(idStr);

        int filasAfectadas = dbOperations.actualizarUsuario(existingUserId, nombre, edad, objetivo);

        if (filasAfectadas > 0) {
            mostrarMensaje("Usuario actualizado exitosamente");
            irAMenuPrincipal(existingUserId);
        } else {
            mostrarMensaje("Error al actualizar usuario. Verifica el ID.");
        }
    }

    // ---------- NAVEGACIÓN ----------

    private void irAMenuPrincipal(long userId) {
        Intent intent = new Intent(this, MenuPrincipalActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
        finish();
    }

    // ---------- UTILIDADES ----------

    private void mostrarMensaje(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbOperations != null) dbOperations.close();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (dbOperations != null) dbOperations.open();
    }
}
