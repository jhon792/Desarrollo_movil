package com.example.desarrollo_movil21_activity;

import com.example.desarrollo_movil21_activity.bdLite.DatabaseOperations;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pantalla2Activity extends AppCompatActivity {
    // …


private Button btnSiguiente;
    private EditText etNombre, etEdad, etObjetivo;
    private DatabaseOperations dbOperations;
    private String alias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.pantalla2), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicializar base de datos
        dbOperations = new DatabaseOperations(this);
        dbOperations.open();

        // Obtener alias del Intent
        alias = getIntent().getStringExtra("ALIAS");

        // Referenciar elementos
        btnSiguiente = findViewById(R.id.btnSiguienteUsuario);
        etNombre = findViewById(R.id.etNombre);
        etEdad = findViewById(R.id.etEdad);
        etObjetivo = findViewById(R.id.etObjetivo);

        btnSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrarUsuario();
            }
        });
    }

    private void registrarUsuario() {
        String nombre = etNombre.getText().toString().trim();
        String edadStr = etEdad.getText().toString().trim();
        String objetivo = etObjetivo.getText().toString().trim();

        if (nombre.isEmpty() || edadStr.isEmpty() || objetivo.isEmpty()) {
            Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int edad = Integer.parseInt(edadStr);

            // Registrar usuario en la base de datos
            long userId = dbOperations.agregarUsuario(alias, nombre, edad, objetivo);

            if (userId != -1) {
                Toast.makeText(this, "Usuario registrado exitosamente", Toast.LENGTH_SHORT).show();

                // Ir al MENÚ PRINCIPAL (no a Pantalla3)
                Intent intent = new Intent(this, MenuPrincipalActivity.class);
                intent.putExtra("USER_ID", userId);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Error al registrar usuario", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Por favor ingresa una edad válida", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbOperations != null) {
            dbOperations.close();
        }
    }
}