package com.example.desarrollo_movil21_activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.desarrollo_movil21_activity.bdLite.DatabaseOperations;

public class Pantalla3Activity extends AppCompatActivity {

    private long userId;
    private DatabaseOperations dbOperations;

    private EditText etIdRutina, etNombreEjercicio, etRepeticiones, etDuracion, etFecha;
    private Button btnAtrasRutina, btnSiguienteRutina;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla3);

        // Obtener USER_ID
        userId = getIntent().getLongExtra("USER_ID", -1);

        // Inicializar base de datos
        dbOperations = new DatabaseOperations(this);
        dbOperations.open();

        // Referencias a los campos
        etIdRutina = findViewById(R.id.etIdRutina);
        etNombreEjercicio = findViewById(R.id.etNombreEjercicio);
        etRepeticiones = findViewById(R.id.etRepeticiones);
        etDuracion = findViewById(R.id.etDuracion);
        etFecha = findViewById(R.id.etFecha);

        // Referencias a botones
        btnAtrasRutina = findViewById(R.id.btnAtrasRutina);
        btnSiguienteRutina = findViewById(R.id.btnSiguienteRutina);

        // Botón para regresar al menú principal
        btnAtrasRutina.setOnClickListener(v -> {
            Intent intent = new Intent(this, MenuPrincipalActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            finish();
        });

        // Botón para guardar rutina y avanzar
        btnSiguienteRutina.setOnClickListener(v -> guardarRutina());
    }

    private void guardarRutina() {
        String nombreEjercicio = etNombreEjercicio.getText().toString().trim();
        String repeticionesStr = etRepeticiones.getText().toString().trim();
        String duracionStr = etDuracion.getText().toString().trim();
        String fecha = etFecha.getText().toString().trim();

        if (nombreEjercicio.isEmpty() || repeticionesStr.isEmpty() || duracionStr.isEmpty() || fecha.isEmpty()) {
            Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        int repeticiones, duracion;
        try {
            repeticiones = Integer.parseInt(repeticionesStr);
            duracion = Integer.parseInt(duracionStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Repeticiones y duración deben ser números válidos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Guardar en la base de datos
        long result = dbOperations.agregarRutina(nombreEjercicio, repeticiones, duracion, fecha, userId);

        if (result != -1) {
            Toast.makeText(this, "Rutina agregada correctamente", Toast.LENGTH_SHORT).show();
            // Opcional: limpiar campos
            etIdRutina.setText("");
            etNombreEjercicio.setText("");
            etRepeticiones.setText("");
            etDuracion.setText("");
            etFecha.setText("");
        } else {
            Toast.makeText(this, "Error al agregar rutina", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbOperations != null) {
            dbOperations.close();
        }
    }
}
