package com.example.desarrollo_movil21_activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.desarrollo_movil21_activity.bdLite.DatabaseOperations;

import java.util.ArrayList;
import java.util.List;

public class RutinasActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RutinaAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rutinas);

        recyclerView = findViewById(R.id.recyclerRutinas);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // Lista de rutinas
        List<Rutina> listaRutinas = new ArrayList<>();
        listaRutinas.add(new Rutina("Pecho", "Press, Aperturas, Fondos", R.drawable.rutinapecho));
        listaRutinas.add(new Rutina("Espalda", "Dominadas, Remo, Jalones", R.drawable.rutinaespalda));
        listaRutinas.add(new Rutina("Pierna", "Sentadillas, Prensa, Curl", R.drawable.rutinapierna));

        // Configurar Adapter
        adapter = new RutinaAdapter(listaRutinas);
        recyclerView.setAdapter(adapter);
    }

    // --- Clase Rutina ---
    public static class Rutina {
        String nombre;
        String descripcion;
        int imagenResId;

        public Rutina(String nombre, String descripcion, int imagenResId) {
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.imagenResId = imagenResId;
        }
    }

    // --- Adapter ---
    public class RutinaAdapter extends RecyclerView.Adapter<RutinaAdapter.RutinaViewHolder> {

        private final List<Rutina> rutinas;

        public RutinaAdapter(List<Rutina> rutinas) {
            this.rutinas = rutinas;
        }

        @Override
        public RutinaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            // Cambié el layout a uno simple de card, no usar ScrollView ni GridLayout dentro del item
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_rutina_card, parent, false);
            return new RutinaViewHolder(view);
        }

        @Override
        public void onBindViewHolder(RutinaViewHolder holder, int position) {
            Rutina rutina = rutinas.get(position);

            holder.imgRutina.setImageResource(rutina.imagenResId);
            holder.txtNombre.setText(rutina.nombre);
            holder.txtDescripcion.setText(rutina.descripcion);

            // Click en la tarjeta
            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(RutinasActivity.this, RutinaDetalleActivity.class);
                intent.putExtra("nombre", rutina.nombre);
                intent.putExtra("descripcion", rutina.descripcion);
                intent.putExtra("imagen", rutina.imagenResId);
                startActivity(intent);
            });
        }

        @Override
        public int getItemCount() {
            return rutinas.size();
        }

        class RutinaViewHolder extends RecyclerView.ViewHolder {
            ImageView imgRutina;
            TextView txtNombre, txtDescripcion;

            RutinaViewHolder(View itemView) {
                super(itemView);
                imgRutina = itemView.findViewById(R.id.imgRutina);
                txtNombre = itemView.findViewById(R.id.txtNombreRutina);
                txtDescripcion = itemView.findViewById(R.id.txtDescripcionRutina);
            }
        }
    }
}
