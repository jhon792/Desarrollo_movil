package com.example.desarrollo_movil21_activity.bdLite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class DatabaseOperations {

    private static final String TAG = "DatabaseOperations";
    private final DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    public DatabaseOperations(Context context) {
        dbHelper = new DatabaseHelper(context.getApplicationContext());
    }

    public void open() {
        try {
            if (database == null || !database.isOpen()) {
                database = dbHelper.getWritableDatabase();
                Log.i(TAG, "Base de datos abierta correctamente.");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error al abrir la base de datos: " + e.getMessage());
        }
    }

    public void close() {
        try {
            if (database != null && database.isOpen()) {
                dbHelper.close();
                database = null;
                Log.i(TAG, "Base de datos cerrada correctamente.");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error al cerrar la base de datos: " + e.getMessage());
        }
    }

    private boolean isOpen() {
        if (database == null || !database.isOpen()) {
            Log.e(TAG, "La base de datos no está abierta. Llama a open() antes de usarla.");
            return false;
        }
        return true;
    }

    // ============================================================
    //  USUARIO
    // ============================================================
    public long agregarUsuario(String alias, String nombre, int edad, String objetivo) {
        open();
        if (!isOpen()) return -1;

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.UsuarioEntry.COLUMN_ALIAS, alias);
        values.put(DatabaseContract.UsuarioEntry.COLUMN_NOMBRE, nombre);
        values.put(DatabaseContract.UsuarioEntry.COLUMN_EDAD, edad);
        values.put(DatabaseContract.UsuarioEntry.COLUMN_OBJETIVO, objetivo);

        return database.insert(DatabaseContract.UsuarioEntry.TABLE_NAME, null, values);
    }

    public int actualizarUsuario(long idUsuario, String nombre, int edad, String objetivo) {
        open();
        if (!isOpen()) return -1;

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.UsuarioEntry.COLUMN_NOMBRE, nombre);
        values.put(DatabaseContract.UsuarioEntry.COLUMN_EDAD, edad);
        values.put(DatabaseContract.UsuarioEntry.COLUMN_OBJETIVO, objetivo);

        String where = DatabaseContract.UsuarioEntry._ID + " = ?";
        String[] args = {String.valueOf(idUsuario)};

        return database.update(DatabaseContract.UsuarioEntry.TABLE_NAME, values, where, args);
    }

    public Cursor obtenerUsuarioPorId(long userId) {
        open();
        if (!isOpen()) return null;

        String selection = DatabaseContract.UsuarioEntry._ID + " = ?";
        String[] args = {String.valueOf(userId)};
        return database.query(DatabaseContract.UsuarioEntry.TABLE_NAME, null, selection, args, null, null, null);
    }

    public Cursor obtenerUsuarioPorAlias(String alias) {
        open();
        if (!isOpen()) return null;

        String selection = DatabaseContract.UsuarioEntry.COLUMN_ALIAS + " = ?";
        String[] args = {alias};
        return database.query(DatabaseContract.UsuarioEntry.TABLE_NAME, null, selection, args, null, null, null);
    }

    // ============================================================
    //  RUTINAS
    // ============================================================
    public long agregarRutina(String nombreEjercicio, int repeticiones, int duracion, String fecha, long idUsuario) {
        open();
        if (!isOpen()) return -1;

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.RutinaEntry.COLUMN_NOMBRE_EJERCICIO, nombreEjercicio);
        values.put(DatabaseContract.RutinaEntry.COLUMN_REPETICIONES, repeticiones);
        values.put(DatabaseContract.RutinaEntry.COLUMN_DURACION, duracion);
        values.put(DatabaseContract.RutinaEntry.COLUMN_FECHA, fecha);
        values.put(DatabaseContract.RutinaEntry.COLUMN_ID_USUARIO, idUsuario);

        return database.insert(DatabaseContract.RutinaEntry.TABLE_NAME, null, values);
    }

    public Cursor obtenerRutinasPorUsuario(long idUsuario) {
        open();
        if (!isOpen()) return null;

        String selection = DatabaseContract.RutinaEntry.COLUMN_ID_USUARIO + " = ?";
        String[] args = {String.valueOf(idUsuario)};

        return database.query(
                DatabaseContract.RutinaEntry.TABLE_NAME,
                null,
                selection,
                args,
                null,
                null,
                DatabaseContract.RutinaEntry.COLUMN_FECHA + " DESC"
        );
    }

    // ============================================================
    //  ACTIVIDAD AsignarDiaActivity
    // ============================================================
    public long guardarRutina(String diaSemana, String nombreRutina) {
        open();
        if (!isOpen()) return -1;

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.RutinaAsignadaEntry.COLUMN_DIA_SEMANA, diaSemana);
        values.put(DatabaseContract.RutinaAsignadaEntry.COLUMN_NOMBRE_RUTINA, nombreRutina);

        return database.insert(DatabaseContract.RutinaAsignadaEntry.TABLE_NAME, null, values);
    }

    // ============================================================
    //  PROGRESO
    // ============================================================
    public long agregarProgreso(String fecha, String nota, String rutaFoto, long idUsuario) {
        open();
        if (!isOpen()) return -1;

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.ProgresoEntry.COLUMN_FECHA, fecha);
        values.put(DatabaseContract.ProgresoEntry.COLUMN_NOTA, nota);
        values.put(DatabaseContract.ProgresoEntry.COLUMN_RUTA_FOTO, rutaFoto);
        values.put(DatabaseContract.ProgresoEntry.COLUMN_ID_USUARIO, idUsuario);

        return database.insert(DatabaseContract.ProgresoEntry.TABLE_NAME, null, values);
    }

    // ============================================================
    //  NOTIFICACIONES
    // ============================================================
    public long agregarNotificacion(String mensaje, String horaProgramada, String opcionSeleccionada, long idUsuario) {
        open();
        if (!isOpen()) return -1;

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.NotificacionEntry.COLUMN_MENSAJE, mensaje);
        values.put(DatabaseContract.NotificacionEntry.COLUMN_HORA_PROGRAMADA, horaProgramada);
        values.put(DatabaseContract.NotificacionEntry.COLUMN_OPCION_SELECCIONADA, opcionSeleccionada);
        values.put(DatabaseContract.NotificacionEntry.COLUMN_ID_USUARIO, idUsuario);
        values.put(DatabaseContract.NotificacionEntry.COLUMN_ACTIVA, 1);

        return database.insert(DatabaseContract.NotificacionEntry.TABLE_NAME, null, values);
    }

    public int desactivarNotificacion(long idNotificacion) {
        open();
        if (!isOpen()) return -1;

        ContentValues values = new ContentValues();
        values.put(DatabaseContract.NotificacionEntry.COLUMN_ACTIVA, 0);

        String where = DatabaseContract.NotificacionEntry._ID + " = ?";
        String[] args = {String.valueOf(idNotificacion)};

        return database.update(DatabaseContract.NotificacionEntry.TABLE_NAME, values, where, args);
    }

    public Cursor obtenerNotificacionesActivas(long idUsuario) {
        open();
        if (!isOpen()) return null;

        String selection = DatabaseContract.NotificacionEntry.COLUMN_ID_USUARIO +
                " = ? AND " + DatabaseContract.NotificacionEntry.COLUMN_ACTIVA + " = 1";

        String[] args = {String.valueOf(idUsuario)};

        return database.query(
                DatabaseContract.NotificacionEntry.TABLE_NAME,
                null,
                selection,
                args,
                null,
                null,
                DatabaseContract.NotificacionEntry.COLUMN_HORA_PROGRAMADA + " ASC"
        );
    }
}
