package com.example.desarrollo_movil21_activity;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;

public class Pantalla4Activity extends AppCompatActivity {

    private static final int REQUEST_CAMERA_PERMISSION = 100;

    private ImageView imagen;
    private Button botonFoto, btnGuardar;
    private EditText etFecha;
    private Uri fotoUri;
    private byte[] fotoBytes;

    private final ActivityResultLauncher<Intent> lanzarCamara = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    imagen.setImageURI(fotoUri);
                    try {
                        fotoBytes = leerBytes(fotoUri);
                    } catch (Exception e) {
                        Log.e("Pantalla4", "Error al leer bytes de la foto", e);
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla4);

        imagen = findViewById(R.id.camara);
        botonFoto = findViewById(R.id.boton_foto);
        btnGuardar = findViewById(R.id.btnGuardarFoto);
        etFecha = findViewById(R.id.etFecha);

        // Configurar DatePicker
        etFecha.setOnClickListener(v -> mostrarDatePicker());

        botonFoto.setOnClickListener(v -> verificarPermisosYTomarFoto());
        btnGuardar.setOnClickListener(v -> guardarEnGaleria());
    }

    private void mostrarDatePicker() {
        Calendar calendario = Calendar.getInstance();
        int year = calendario.get(Calendar.YEAR);
        int month = calendario.get(Calendar.MONTH);
        int day = calendario.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String fecha = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                    etFecha.setText(fecha);
                }, year, month, day);

        datePickerDialog.show();
    }

    private void verificarPermisosYTomarFoto() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_CAMERA_PERMISSION
            );
        } else {
            tomarFoto();
        }
    }

    private void tomarFoto() {
        Intent intentCamara = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "Foto Progreso");
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000);

        fotoUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
        );

        intentCamara.putExtra(MediaStore.EXTRA_OUTPUT, fotoUri);
        lanzarCamara.launch(intentCamara);
    }

    private void guardarEnGaleria() {
        if (fotoBytes == null) {
            Toast.makeText(this, "Primero toma una foto", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            OutputStream outputStream = getContentResolver().openOutputStream(fotoUri);
            outputStream.write(fotoBytes);
            outputStream.close();
            Toast.makeText(this, "Foto guardada en Galería 📸", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error al guardar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private byte[] leerBytes(Uri uri) throws Exception {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] data = new byte[1024];
        int nRead;
        while ((nRead = inputStream.read(data)) != -1) {
            buffer.write(data, 0, nRead);
        }
        inputStream.close();
        return buffer.toByteArray();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                tomarFoto();
            } else {
                Toast.makeText(this, "Permiso de cámara denegado", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
