package com.example.desarrollo_movil21_activity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.desarrollo_movil21_activity.bdLite.DatabaseContract;
import com.example.desarrollo_movil21_activity.bdLite.DatabaseOperations;

public class MenuPrincipalActivity extends AppCompatActivity {

    private long userId;
    private DatabaseOperations dbOperations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        // Obtener ID del usuario
        userId = getIntent().getLongExtra("USER_ID", -1);

        // Inicializar base de datos
        dbOperations = new DatabaseOperations(this);
        dbOperations.open();

        // Mostrar info del usuario
        mostrarInfoUsuario();

        // Configurar botones de navegación
        Button btnRutinas = findViewById(R.id.btnRutinas);
        Button btnProgreso = findViewById(R.id.btnProgreso);
        Button btnNotificaciones = findViewById(R.id.btnNotificaciones);
        Button btnCerrarSesion = findViewById(R.id.btnCerrarSesion);

        // Redirigir botones a actividades existentes
        btnRutinas.setOnClickListener(v -> irARutinas());        // Cambiado
        btnProgreso.setOnClickListener(v -> irAPantalla4());
        btnNotificaciones.setOnClickListener(v -> irAPantalla5());
        btnCerrarSesion.setOnClickListener(v -> cerrarSesion());
    }

    private void mostrarInfoUsuario() {
        if (userId != -1) {
            Cursor cursor = dbOperations.obtenerUsuarioPorId(userId);
            if (cursor != null && cursor.moveToFirst()) {

                String nombre = cursor.getString(
                        cursor.getColumnIndexOrThrow(DatabaseContract.UsuarioEntry.COLUMN_NOMBRE)
                );
                String alias = cursor.getString(
                        cursor.getColumnIndexOrThrow(DatabaseContract.UsuarioEntry.COLUMN_ALIAS)
                );

                TextView tvBienvenida = findViewById(R.id.tvBienvenida);
                if (tvBienvenida != null) {
                    tvBienvenida.setText("¡Bienvenido, " + (nombre != null ? nombre : alias) + "!");
                }

                cursor.close();
            }
        }
    }

    private void irARutinas() {
        Intent intent = new Intent(this, RutinasActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }


    private void irAPantalla4() {
        Intent intent = new Intent(this, Pantalla4Activity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }

    private void irAPantalla5() {
        Intent intent = new Intent(this, Pantalla5Activity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }

    private void cerrarSesion() {
        Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbOperations != null) {
            dbOperations.close();
        }
    }
}
