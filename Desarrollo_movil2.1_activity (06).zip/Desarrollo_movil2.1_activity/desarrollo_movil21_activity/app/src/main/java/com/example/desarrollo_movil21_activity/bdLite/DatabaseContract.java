package com.example.desarrollo_movil21_activity.bdLite;

import android.provider.BaseColumns;

/**
 * Clase contract que define la estructura de la base de datos SQLite.
 * Contiene únicamente constantes: nombre de tablas y columnas.
 */
public final class DatabaseContract {

    private DatabaseContract() {}

    /**
     * Tabla de Usuarios
     */
    public static final class UsuarioEntry implements BaseColumns {
        public static final String TABLE_NAME = "usuarios";
        public static final String COLUMN_ALIAS = "alias";
        public static final String COLUMN_NOMBRE = "nombre";
        public static final String COLUMN_EDAD = "edad";
        public static final String COLUMN_OBJETIVO = "objetivo";
        public static final String COLUMN_FECHA_REGISTRO = "fecha_registro";

        public static final String SQL_CREATE =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_ALIAS + " TEXT UNIQUE NOT NULL, " +
                        COLUMN_NOMBRE + " TEXT, " +
                        COLUMN_EDAD + " INTEGER, " +
                        COLUMN_OBJETIVO + " TEXT, " +
                        COLUMN_FECHA_REGISTRO + " TEXT" +
                        ");";

        public static final String SQL_DROP = "DROP TABLE IF EXISTS " + TABLE_NAME;
    }

    /**
     * Tabla de Rutinas
     */
    public static final class RutinaEntry implements BaseColumns {
        public static final String TABLE_NAME = "rutinas";
        public static final String COLUMN_NOMBRE_EJERCICIO = "nombre_ejercicio";
        public static final String COLUMN_REPETICIONES = "repeticiones";
        public static final String COLUMN_DURACION = "duracion";
        public static final String COLUMN_FECHA = "fecha";
        public static final String COLUMN_ID_USUARIO = "id_usuario";

        public static final String SQL_CREATE =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_NOMBRE_EJERCICIO + " TEXT NOT NULL, " +
                        COLUMN_REPETICIONES + " INTEGER, " +
                        COLUMN_DURACION + " TEXT, " +
                        COLUMN_FECHA + " TEXT, " +
                        COLUMN_ID_USUARIO + " INTEGER, " +
                        "FOREIGN KEY(" + COLUMN_ID_USUARIO + ") REFERENCES " +
                        UsuarioEntry.TABLE_NAME + "(" + UsuarioEntry._ID + ")" +
                        ");";

        public static final String SQL_DROP = "DROP TABLE IF EXISTS " + TABLE_NAME;
    }

    /**
     * Tabla de Rutinas Asignadas a días de la semana
     */
    public static final class RutinaAsignadaEntry implements BaseColumns {
        public static final String TABLE_NAME = "rutinas_asignadas";
        public static final String COLUMN_ID_USUARIO = "id_usuario";
        public static final String COLUMN_DIA_SEMANA = "dia_semana";
        public static final String COLUMN_NOMBRE_RUTINA = "nombre_rutina";

        public static final String SQL_CREATE =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_ID_USUARIO + " INTEGER NOT NULL, " +
                        COLUMN_DIA_SEMANA + " TEXT NOT NULL, " +
                        COLUMN_NOMBRE_RUTINA + " TEXT NOT NULL, " +
                        "FOREIGN KEY(" + COLUMN_ID_USUARIO + ") REFERENCES " +
                        UsuarioEntry.TABLE_NAME + "(" + UsuarioEntry._ID + ")" +
                        ");";

        public static final String SQL_DROP = "DROP TABLE IF EXISTS " + TABLE_NAME;
    }

    /**
     * Tabla de Progreso (fotos, notas, fechas)
     */
    public static final class ProgresoEntry implements BaseColumns {
        public static final String TABLE_NAME = "progreso";
        public static final String COLUMN_FECHA = "fecha";
        public static final String COLUMN_NOTA = "nota";
        public static final String COLUMN_RUTA_FOTO = "ruta_foto";
        public static final String COLUMN_ID_USUARIO = "id_usuario";

        public static final String SQL_CREATE =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_FECHA + " TEXT NOT NULL, " +
                        COLUMN_NOTA + " TEXT, " +
                        COLUMN_RUTA_FOTO + " TEXT, " +
                        COLUMN_ID_USUARIO + " INTEGER, " +
                        "FOREIGN KEY(" + COLUMN_ID_USUARIO + ") REFERENCES " +
                        UsuarioEntry.TABLE_NAME + "(" + UsuarioEntry._ID + ")" +
                        ");";

        public static final String SQL_DROP = "DROP TABLE IF EXISTS " + TABLE_NAME;
    }

    /**
     * Tabla de Notificaciones
     */
    public static final class NotificacionEntry implements BaseColumns {
        public static final String TABLE_NAME = "notificaciones";
        public static final String COLUMN_MENSAJE = "mensaje";
        public static final String COLUMN_HORA_PROGRAMADA = "hora_programada";
        public static final String COLUMN_OPCION_SELECCIONADA = "opcion_seleccionada";
        public static final String COLUMN_ACTIVA = "activa";
        public static final String COLUMN_ID_USUARIO = "id_usuario";

        public static final String SQL_CREATE =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_MENSAJE + " TEXT NOT NULL, " +
                        COLUMN_HORA_PROGRAMADA + " TEXT, " +
                        COLUMN_OPCION_SELECCIONADA + " TEXT, " +
                        COLUMN_ACTIVA + " INTEGER NOT NULL DEFAULT 1, " +
                        COLUMN_ID_USUARIO + " INTEGER, " +
                        "FOREIGN KEY(" + COLUMN_ID_USUARIO + ") REFERENCES " +
                        UsuarioEntry.TABLE_NAME + "(" + UsuarioEntry._ID + ")" +
                        ");";

        public static final String SQL_DROP = "DROP TABLE IF EXISTS " + TABLE_NAME;
    }
}
