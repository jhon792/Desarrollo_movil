package com.example.desarrollo_movil21_activity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.desarrollo_movil21_activity.bdLite.DatabaseOperations;

public class Pantalla5Activity extends AppCompatActivity {

    private DatabaseOperations dbOperations;
    private long userId;

    private EditText etMensaje, etHoraProgramada;
    private Spinner spinnerOpciones;
    private Button btnGuardarNotificacion;

    private String opcionSeleccionada = "";

    // ✔ Debe coincidir con Manifest y BroadcastReceiver
    private static final String ACTION_ALARMA =
            "com.example.desarrollo_movil21_activity.ALARMA_RECIBIDA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla5);

        userId = getIntent().getLongExtra("USER_ID", -1);

        dbOperations = new DatabaseOperations(this);
        dbOperations.open();

        etMensaje = findViewById(R.id.etMensaje);
        etHoraProgramada = findViewById(R.id.etHoraProgramada);
        spinnerOpciones = findViewById(R.id.spinnerOpciones);
        btnGuardarNotificacion = findViewById(R.id.btnGuardarNotificacion);

        etHoraProgramada.setFocusable(false);
        etHoraProgramada.setOnClickListener(v -> mostrarTimePicker());

        configurarSpinner();

        btnGuardarNotificacion.setOnClickListener(v -> guardarNotificacion());

        cargarNotificacionesExistentes();
    }

    private void mostrarTimePicker() {
        java.util.Calendar calendario = java.util.Calendar.getInstance();
        int horaActual = calendario.get(java.util.Calendar.HOUR_OF_DAY);
        int minutoActual = calendario.get(java.util.Calendar.MINUTE);

        TimePickerDialog timePicker = new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    String horaFormateada = String.format("%02d:%02d", hourOfDay, minute);
                    etHoraProgramada.setText(horaFormateada);
                },
                horaActual,
                minutoActual,
                true
        );

        timePicker.show();
    }

    private void configurarSpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.opciones,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerOpciones.setAdapter(adapter);

        spinnerOpciones.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                opcionSeleccionada = parent.getItemAtPosition(position).toString();
                autoCompletarMensaje(opcionSeleccionada);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                opcionSeleccionada = "";
            }
        });
    }

    private void autoCompletarMensaje(String opcion) {
        switch (opcion) {
            case "Recordatorio de ejercicio":
                etMensaje.setText("¡Es hora de hacer ejercicio! 💪");
                break;
            case "Recordatorio de descanso":
                etMensaje.setText("¡Recuerda tomar un descanso! 🧘");
                break;
            case "Consejo de nutrición":
                etMensaje.setText("¡No olvides mantener una alimentación balanceada! 🥗");
                break;
            case "Recordatorio de hidratación":
                etMensaje.setText("¡Es hora de hidratarte! 💧");
                break;
            case "Motivación":
                etMensaje.setText("¡Tú puedes lograr tus objetivos! 🌟");
                break;
        }
    }

    private void guardarNotificacion() {
        String mensaje = etMensaje.getText().toString().trim();
        String horaProgramada = etHoraProgramada.getText().toString().trim();

        if (mensaje.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa un mensaje", Toast.LENGTH_SHORT).show();
            return;
        }

        if (horaProgramada.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa la hora programada", Toast.LENGTH_SHORT).show();
            return;
        }

        if (opcionSeleccionada.isEmpty()) {
            Toast.makeText(this, "Por favor selecciona un tipo de notificación", Toast.LENGTH_SHORT).show();
            return;
        }

        long resultado = dbOperations.agregarNotificacion(mensaje, horaProgramada, opcionSeleccionada, userId);

        if (resultado != -1) {
            programarAlarma(mensaje, horaProgramada, resultado);
            Toast.makeText(this, "Notificación guardada", Toast.LENGTH_SHORT).show();
            limpiarCampos();
        } else {
            Toast.makeText(this, "Error al guardar", Toast.LENGTH_SHORT).show();
        }
    }

    // 🎯 CÓDIGO CORREGIDO Y FUNCIONANDO
    private void programarAlarma(String mensaje, String horaProgramada, long notificacionId) {
        try {
            String[] partes = horaProgramada.split(":");
            int hora = Integer.parseInt(partes[0]);
            int minuto = Integer.parseInt(partes[1]);

            long tiempoAlarma = calcularTiempoAlarma(hora, minuto);

            // ✔ ESTA ES LA FORMA CORRECTA
            Intent intent = new Intent(this, Notificaciones.class);
            intent.setAction(ACTION_ALARMA);
            intent.putExtra("MENSAJE", mensaje);
            intent.putExtra("NOTIFICACION_ID", notificacionId);

            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    this,
                    (int) notificacionId,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    tiempoAlarma,
                    pendingIntent
            );

            Toast.makeText(this, "Alarma programada para " + horaProgramada, Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private long calcularTiempoAlarma(int hora, int minuto) {
        java.util.Calendar calendario = java.util.Calendar.getInstance();
        long ahora = System.currentTimeMillis();

        calendario.set(java.util.Calendar.HOUR_OF_DAY, hora);
        calendario.set(java.util.Calendar.MINUTE, minuto);
        calendario.set(java.util.Calendar.SECOND, 0);

        long tiempo = calendario.getTimeInMillis();

        if (tiempo <= ahora) {
            tiempo += 24 * 60 * 60 * 1000;
        }

        return tiempo;
    }

    private void cargarNotificacionesExistentes() {
        if (userId != -1) {
            Cursor cursor = dbOperations.obtenerNotificacionesActivas(userId);
            if (cursor != null) {
                Toast.makeText(this, "Notificaciones activas: " + cursor.getCount(), Toast.LENGTH_SHORT).show();
                cursor.close();
            }
        }
    }

    private void limpiarCampos() {
        etMensaje.setText("");
        etHoraProgramada.setText("");
        spinnerOpciones.setSelection(0);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbOperations.close();
    }

    @Override
    protected void onResume() {
        super.onResume();
        dbOperations.open();
    }
}
