package com.example.desarrollo_movil21_activity.bdLite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "FitnessTracker.db";
    private static final int DATABASE_VERSION = 2; // Incrementado para soportar upgrades

    // Activar claves foráneas
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    // ---------------------------
    // SENTENCIAS SQL
    // ---------------------------

    private static final String SQL_CREATE_USUARIOS =
            "CREATE TABLE " + DatabaseContract.UsuarioEntry.TABLE_NAME + " (" +
                    DatabaseContract.UsuarioEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    DatabaseContract.UsuarioEntry.COLUMN_ALIAS + " TEXT UNIQUE NOT NULL, " +
                    DatabaseContract.UsuarioEntry.COLUMN_NOMBRE + " TEXT NOT NULL, " +
                    DatabaseContract.UsuarioEntry.COLUMN_EDAD + " INTEGER CHECK(" +
                    DatabaseContract.UsuarioEntry.COLUMN_EDAD + " > 0), " +
                    DatabaseContract.UsuarioEntry.COLUMN_OBJETIVO + " TEXT, " +
                    DatabaseContract.UsuarioEntry.COLUMN_FECHA_REGISTRO + " TEXT DEFAULT CURRENT_TIMESTAMP" +
                    ");";

    private static final String SQL_CREATE_RUTINAS =
            "CREATE TABLE " + DatabaseContract.RutinaEntry.TABLE_NAME + " (" +
                    DatabaseContract.RutinaEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    DatabaseContract.RutinaEntry.COLUMN_NOMBRE_EJERCICIO + " TEXT NOT NULL, " +
                    DatabaseContract.RutinaEntry.COLUMN_REPETICIONES + " INTEGER, " +
                    DatabaseContract.RutinaEntry.COLUMN_DURACION + " INTEGER, " +
                    DatabaseContract.RutinaEntry.COLUMN_FECHA + " TEXT NOT NULL, " +
                    DatabaseContract.RutinaEntry.COLUMN_ID_USUARIO + " INTEGER NOT NULL, " +
                    "FOREIGN KEY(" + DatabaseContract.RutinaEntry.COLUMN_ID_USUARIO + ") REFERENCES " +
                    DatabaseContract.UsuarioEntry.TABLE_NAME + "(" + DatabaseContract.UsuarioEntry._ID + ") ON DELETE CASCADE" +
                    ");";

    private static final String SQL_CREATE_PROGRESO =
            "CREATE TABLE " + DatabaseContract.ProgresoEntry.TABLE_NAME + " (" +
                    DatabaseContract.ProgresoEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    DatabaseContract.ProgresoEntry.COLUMN_FECHA + " TEXT NOT NULL, " +
                    DatabaseContract.ProgresoEntry.COLUMN_NOTA + " TEXT, " +
                    DatabaseContract.ProgresoEntry.COLUMN_RUTA_FOTO + " TEXT, " +
                    DatabaseContract.ProgresoEntry.COLUMN_ID_USUARIO + " INTEGER NOT NULL, " +
                    "FOREIGN KEY(" + DatabaseContract.ProgresoEntry.COLUMN_ID_USUARIO + ") REFERENCES " +
                    DatabaseContract.UsuarioEntry.TABLE_NAME + "(" + DatabaseContract.UsuarioEntry._ID + ") ON DELETE CASCADE" +
                    ");";

    private static final String SQL_CREATE_NOTIFICACIONES =
            "CREATE TABLE " + DatabaseContract.NotificacionEntry.TABLE_NAME + " (" +
                    DatabaseContract.NotificacionEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    DatabaseContract.NotificacionEntry.COLUMN_MENSAJE + " TEXT NOT NULL, " +
                    DatabaseContract.NotificacionEntry.COLUMN_HORA_PROGRAMADA + " TEXT, " +
                    DatabaseContract.NotificacionEntry.COLUMN_OPCION_SELECCIONADA + " TEXT, " +
                    DatabaseContract.NotificacionEntry.COLUMN_ACTIVA + " INTEGER DEFAULT 1, " +
                    DatabaseContract.NotificacionEntry.COLUMN_ID_USUARIO + " INTEGER NOT NULL, " +
                    "FOREIGN KEY(" + DatabaseContract.NotificacionEntry.COLUMN_ID_USUARIO + ") REFERENCES " +
                    DatabaseContract.UsuarioEntry.TABLE_NAME + "(" + DatabaseContract.UsuarioEntry._ID + ") ON DELETE CASCADE" +
                    ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Crear las tablas
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_USUARIOS);
        db.execSQL(SQL_CREATE_RUTINAS);
        db.execSQL(SQL_CREATE_PROGRESO);
        db.execSQL(SQL_CREATE_NOTIFICACIONES);
    }

    // Manejar actualizaciones de versión sin perder datos
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // EJEMPLO: Si necesitas trabajar versiones específicas
        if (oldVersion < 2) {
            // Aquí puedes añadir nuevas columnas sin borrar datos
            // db.execSQL("ALTER TABLE ...");
        }
    }
}
