package com.example.desarrollo_movil21_activity;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.example.desarrollo_movil21_activity.bdLite.DatabaseOperations;

public class Notificaciones extends BroadcastReceiver {

    private static final String CHANNEL_ID = "fitness_notifications";
    private static final String ACTION_ALARMA =
            "com.example.desarrollo_movil21_activity.ALARMA_RECIBIDA";

    @Override
    public void onReceive(Context context, Intent intent) {

        if (intent == null || intent.getAction() == null) {
            Log.e("Notificaciones", "Intent null o sin ACTION");
            return;
        }

        // ✔ VALIDACIÓN OBLIGATORIA DEL ACTION
        if (!ACTION_ALARMA.equals(intent.getAction())) {
            Log.e("Notificaciones", "ACTION incorrecta: " + intent.getAction());
            return;
        }

        String mensaje = intent.getStringExtra("MENSAJE");
        long notificacionId = intent.getLongExtra("NOTIFICACION_ID", System.currentTimeMillis());

        if (mensaje == null || mensaje.isEmpty()) {
            mensaje = "¡Es hora de tu actividad fitness!";
        }

        mostrarNotificacion(context, mensaje, (int) notificacionId);

        marcarNotificacionComoInactiva(context, notificacionId);
    }

    private void mostrarNotificacion(Context context, String mensaje, int id) {

        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        crearCanalNotificacion(nm);

        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                id,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Mi App Fitness")
                .setContentText(mensaje)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(mensaje))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        nm.notify(id, builder.build());
    }

    private void crearCanalNotificacion(NotificationManager nm) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Recordatorios Fitness",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Canal de notificaciones de recordatorios fitness");
            nm.createNotificationChannel(channel);
        }
    }

    private void marcarNotificacionComoInactiva(Context context, long id) {
        try {
            DatabaseOperations db = new DatabaseOperations(context);
            db.open();
            db.desactivarNotificacion(id);
            db.close();

            Log.d("Notificaciones", "Notificación desactivada ID = " + id);

        } catch (Exception e) {
            Log.e("Notificaciones", "Error al desactivar notificación", e);
        }
    }
}
