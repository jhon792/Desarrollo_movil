package com.example.desarrollo_movil21_activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class RutinaDetalleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rutina_detalle);

        ImageView imgRutina = findViewById(R.id.imgRutinaDetalle);
        TextView txtNombre = findViewById(R.id.txtNombreRutinaDetalle);
        TextView txtDescripcion = findViewById(R.id.txtDescripcionRutinaDetalle);
        Button btnAsignar = findViewById(R.id.btnAsignarDia);

        // Recibir datos de la rutina
        Intent intent = getIntent();
        String nombre = intent.getStringExtra("nombre");
        String descripcion = intent.getStringExtra("descripcion");
        int imagenResId = intent.getIntExtra("imagen", R.drawable.rutinapecho);

        txtNombre.setText(nombre);
        txtDescripcion.setText(descripcion);
        imgRutina.setImageResource(imagenResId);

        btnAsignar.setOnClickListener(v -> {
            Intent i = new Intent(RutinaDetalleActivity.this, AsignarDiaActivity.class);
            i.putExtra("nombre", nombre);
            i.putExtra("descripcion", descripcion);
            i.putExtra("imagen", imagenResId);
            startActivity(i);
        });
    }
}
