package com.example.desarrollo_movil21_activity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.example.desarrollo_movil21_activity.bdLite.DatabaseContract;
import com.example.desarrollo_movil21_activity.bdLite.DatabaseOperations;

public class MainActivity extends AppCompatActivity {

    private DatabaseOperations dbOperations;
    private EditText editTextAlias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Back
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                moveTaskToBack(true);
                finish();
            }
        });

        dbOperations = new DatabaseOperations(this);
        dbOperations.open();

        editTextAlias = findViewById(R.id.Alias);
        Button buttonComenzar = findViewById(R.id.lgbutton2);

        buttonComenzar.setOnClickListener(v -> verificarYNavegar());

        editTextAlias.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                verificarYNavegar();
                return true;
            }
            return false;
        });
    }

    private void verificarYNavegar() {
        String alias = editTextAlias.getText().toString().trim();

        if (alias.isEmpty()) {
            Toast.makeText(this, "Por favor ingresa un alias", Toast.LENGTH_SHORT).show();
            return;
        }

        if (alias.length() < 2) {
            Toast.makeText(this, "El alias debe tener al menos 2 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }

        Cursor cursor = null;

        try {
            cursor = dbOperations.obtenerUsuarioPorAlias(alias);

            if (cursor != null && cursor.moveToFirst()) {
                long userId = cursor.getLong(
                        cursor.getColumnIndexOrThrow(DatabaseContract.UsuarioEntry._ID)
                );

                String nombre = cursor.getString(
                        cursor.getColumnIndexOrThrow(DatabaseContract.UsuarioEntry.COLUMN_NOMBRE)
                );

                Toast.makeText(
                        this,
                        (nombre != null && !nombre.isEmpty())
                                ? "¡Bienvenido de nuevo, " + nombre + "!"
                                : "¡Bienvenido de nuevo!",
                        Toast.LENGTH_SHORT
                ).show();

                irAMenuPrincipal(userId);
            } else {
                Toast.makeText(this, "Creando nuevo perfil...", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, Pantalla2Activity.class);
                intent.putExtra("ALIAS", alias);
                startActivity(intent);
            }

        } catch (Exception e) {
            Toast.makeText(this, "Error al verificar usuario: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null) cursor.close();
            editTextAlias.setText("");
        }
    }

    private void irAMenuPrincipal(long userId) {
        Intent intent = new Intent(this, MenuPrincipalActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }
}
